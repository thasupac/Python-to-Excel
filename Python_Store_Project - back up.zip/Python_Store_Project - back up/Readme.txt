วิธีการปฎิบัติในการใช้ ASMT Store
1.ไฟล์ชื่อ config จะรวบรวมดังนี้
	a. path ของ database (excel และรูปภาพ)
	b. ชื่อ sheet ของ excel ที่ต้องการเข้าถึง
	c .ชื่อ template คือเป็นชื่อ form ต่างๆ
	d. exportpath คือตำแหน่งการบันทึกของไฟล์ตอนที่ทำการ export
	e. exportname คือ ชื่อของ form เช่น F-ME344-042
	f. accessoutlook คือการเข้าถึงเมลที่ใช้ในการส่งแจ้งเตือน โดยจะต้องมี username และ password และเมลของผู่ที่ต้องการส่งถึง